"""
Módulo de Python que contiene las rutas
"""
from flask import current_app as app, render_template, redirect, url_for, flash, abort
from sqlalchemy import select, func
from sqlalchemy.orm import selectinload
from . import db
from .formularios import NuevoMazo, AnyadirCarta
from .modelos import Carta, Mazo, CartaEnMazo


@app.route('/')
@app.route('/cartas')
def listar_cartas():
    """
    (+0.3 ptos)

    Funcion que muestra la lista de cartas usando una paginacion,
    invocando al template "lista_cartas.html".
    Se deben mostrar 12 resultados por pagina.
    """
    page = db.paginate(select(Carta), per_page=12)
    return render_template("lista_cartas.html", page=page)


@app.route('/crear_mazo', methods=['GET', 'POST'])
def crear_mazo():
    """
    (+0.3 ptos)

    Funcion que crea un nuevo mazo, a partir del formulario "NuevoMazo".
    Para mostrar el formulario, se invoca al template "crear_mazo.html".
    En caso de crearse un nuevo mazo de forma satisfactoria, se debe redirigir
    a la funcion de vista "listar_cartas".
    En caso contrario, se vuelve a renderizar el formulario de crear mazo.
    """
    nuevo_mazo = NuevoMazo()
    if nuevo_mazo.validate_on_submit():
        nombre_mazo = nuevo_mazo.data["nombre"]
        db.session.add(Mazo(nombre=nombre_mazo))
        db.session.commit()
        return redirect(url_for('listar_cartas'))
    return render_template('crear_mazo.html', form=nuevo_mazo)


@app.route('/mazo/<int:id_mazo>')
def mostrar_mazo_completo(id_mazo: int):
    """
    (+0.7 ptos)

    Dado el id de un mazo, se muestran todas las cartas asociadas a ese mazo.
    Las cartas se muestran separadas por banquillo o no banquillo.
    Si el id de mazo no existe, se debe abortar con error 404. Como resultado, debe
    renderizar el template "mazos.html".
    """
    # Seleccionamos el mazo, sus cartas asociadas en ese mazo, y toda la informacion
    # de cada carta
    mazo = db.first_or_404(select(Mazo)
                           .where(Mazo.id == id_mazo)
                           .options(selectinload(Mazo.cartas_en_mazo)
                                    .selectinload(CartaEnMazo.carta)))

    # Separamos en dos listas las cartas principales y de banquillos
    cartas_base = []
    cartas_banquillo = []
    id_carta2carta = dict()
    for carta_en_mazo in mazo.cartas_en_mazo:
        id_carta2carta[carta_en_mazo.id_carta] = carta_en_mazo.carta
        if carta_en_mazo.banquillo:
            cartas_banquillo.append(carta_en_mazo)
        else:
            cartas_base.append(carta_en_mazo)

    return render_template("mazos.html", mazo=mazo, cartas_base=cartas_base,
                           cartas_banquillo=cartas_banquillo, id2carta=id_carta2carta)


def mostrar_mazos(mazos):
    """
    Funcion auxiliar para mostrar varios mazos de una paginacion
    """
    id_mazo2cartas_en_mazo = dict()
    id_carta2carta = dict()
    for mazo in mazos:
        mazo_id = mazo.id

        subconjunto_cartas = db.session.execute(select(CartaEnMazo, Carta)
                                                .join_from(CartaEnMazo, Carta, CartaEnMazo.id_carta == Carta.id)
                                                .where(CartaEnMazo.id_mazo == mazo_id)
                                                .order_by(func.coalesce(Carta.precio, 0).desc(), Carta.nombre.asc())
                                                .limit(6)
                                                ).fetchall()
        lista_cartas = []
        for carta_en_mazo, carta in subconjunto_cartas:
            lista_cartas.append(carta_en_mazo)
            id_carta2carta[carta.id] = carta

        id_mazo2cartas_en_mazo[mazo_id] = lista_cartas

    return render_template("mazos_preview.html", mazos=mazos, id_mazo2cartas_en_mazo=id_mazo2cartas_en_mazo,
                           id2carta=id_carta2carta)


@app.route('/mazos_preview/')
def mostrar_mazo_preview_global():
    """
    (+0.7 ptos)

    Funcion que muestra la lista de mazos almacenada en el sistema.
    Se deben mostrar un total de 5 mazos por pagina con una paginacion, utilizando el
    template "mazos_preview.html". Por cada mazo, se deben mostrar la informacion de solo 6 de sus cartas.
    Estas cartas se deben seleccionar por su precio de forma descendente, y en caso de empate, por su nombre.
    Si una carta tiene precio nulo, entonces se debe considerar que el precio es 0.
    """
    mazos = db.paginate(select(Mazo), per_page=5)
    return mostrar_mazos(mazos)


@app.route('/mazo/<int:id_mazo>/nueva_carta', methods=['GET', 'POST'])
def introducir_carta_en_mazo(id_mazo: int):
    """
    (+1 pto)

    Funcion para introducir cartas en un mazo concreto. Si el id del
    mazo no existe, se debe abortar con un error 404.

    Para introducir una nueva carta, se debe utilizar el formulario "AnyadirCarta".

    Este formulario recibe como parametro una lista con el nombre de las cartas
    que ya estan almacenadas en el mazo, para evitar volver a introducirlas.

    En caso de que el formulario se valide correctamente, se introduce una nueva carta al mazo
    con la informacion del formulario y se redirige a esta misma funcion con el mazo actual,
    para seguir introduciendo cartas. Tambien se debe actualizar la informacion
    sobre el numero de cartas en un mazo concreto. Por ultimo, se generara un mensaje flash
    indicando que se ha añadido la carta correctamente: "¡Carta añadida correctamente!".

    En caso el formulario no se valide correctamente o que la carta no exista, se debe volver a mostrar el formulario.
    """

    # Primero, recuperamos la informacion del mazo y de las cartas relacionadas.
    # Como solo queremos el nombre de las cartas para saber si lo hemos introducido ya,
    # controlamos el acceso con load_only. Necesitamos dos selectinload:
    # uno para CartaEnMazo y otro para Carta
    mazo = db.session.scalars(select(Mazo)
                              .where(Mazo.id == id_mazo)
                              .options(selectinload(Mazo.cartas_en_mazo)
                                       .load_only(CartaEnMazo.id_carta)
                                       .selectinload(CartaEnMazo.carta)
                                       .load_only(Carta.nombre))).first()

    # Comprobamos que hay un mazo (i.e. no devuelve None la consulta)
    # y que su id es el usuario actual o un administrador
    if mazo is None:
        abort(401)

    # Se podria guardar el formulario en la sesion del usuario para evitar cargar
    # todos los nombres cada vez que añado una carta en el mismo mazo
    formulario_incluir_carta = AnyadirCarta([carta_en_mazo.carta.nombre
                                             for carta_en_mazo in mazo.cartas_en_mazo])

    # Miramos si hay una carta
    if formulario_incluir_carta.validate_on_submit():

        # Recuperamos la informacion
        nombre_carta = formulario_incluir_carta.data["nombre_carta"]
        es_banquillo = formulario_incluir_carta.data['banquillo']
        numero_copias = formulario_incluir_carta.data['numero_copias']

        # Buscamos un id de una carta que coincida
        id_carta = db.session.scalars(select(Carta.id).where(Carta.nombre == nombre_carta)).first()

        if id_carta is not None:
            carta_en_mazo = CartaEnMazo(id_carta=id_carta, id_mazo=id_mazo,
                                        numero_copias=numero_copias, banquillo=es_banquillo is not None)
            flash("¡Carta añadida correctamente!")

            mazo.num_cartas = mazo.num_cartas + numero_copias

            db.session.add(carta_en_mazo)
            db.session.commit()

            # Volvemos a redirigirnos a la misma funcion para seguir incluyendo cartas
            return redirect(url_for(f'introducir_carta_en_mazo', id_mazo=id_mazo))

    return render_template("incluir_carta.html", form=formulario_incluir_carta, id_mazo=id_mazo)
