from typing import List
from . import db
from sqlalchemy import Integer, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship


class Carta(db.Model):
    """
    Cartas de MTG
    """
    id: Mapped[int] = mapped_column(Integer, autoincrement=True, primary_key=True)
    nombre: Mapped[str] = mapped_column()
    precio: Mapped[float] = mapped_column(nullable=True)
    imagen_scryfall: Mapped[str] = mapped_column(nullable=True)
    url_mkm: Mapped[str] = mapped_column(nullable=True)

    # Los mazos en los que aparece una carta
    en_mazos: Mapped[List["CartaEnMazo"]] = relationship(back_populates="carta")


class Mazo(db.Model):
    """
    Mazo de Cartas
    """
    id: Mapped[int] = mapped_column(Integer, autoincrement=True, primary_key=True)
    nombre: Mapped[str] = mapped_column()
    num_cartas: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Relacion entre un mazo y sus cartas
    cartas_en_mazo: Mapped[List["CartaEnMazo"]] = relationship(back_populates="mazo")


class CartaEnMazo(db.Model):
    """
    Representa que una carta está en un mazo, el número de copias asociada, y si está en el banquillo o no.
    """
    id_carta: Mapped[int] = mapped_column(ForeignKey(Carta.id), primary_key=True)
    id_mazo: Mapped[int] = mapped_column(ForeignKey(Mazo.id), primary_key=True)

    # Número de copias de la carta en el mazo
    numero_copias: Mapped[int] = mapped_column(nullable=False)

    # Si la carta pertenece al banquillo o al mazo principal
    banquillo: Mapped[bool] = mapped_column(nullable=False)

    carta: Mapped["Carta"] = relationship(back_populates="en_mazos")
    mazo: Mapped["Mazo"] = relationship(back_populates="cartas_en_mazo")
